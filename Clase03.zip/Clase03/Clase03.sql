-- show databases;
-- drop database if exists Clase02;

-- 1- Borrar si existe la base de datos Agenda.
drop database if exists agenda;

-- 2- Crear la base de datos Agenda.
create database agenda;

-- 3- Ingresar a la base de datos creada.
use agenda;

-- 4- Crear una tabla llamada "agenda". Debe tener los siguientes campos:

--    nombre (cadena de 20), 
--    domicilio (cadena de 30)
--    telefono (cadena de 11)
create table agenda( 
	nombre		varchar(20), 
    direccion 	varchar(30), 
    telefono 	varchar(11)
);

-- 5- Visualizar las tablas existentes en la base de datos para verificar la creación de "agenda".
show tables;

-- 6- Visualizar la estructura de campos de la tabla "agenda". (describe).
describe agenda;

-- 7- Ingresar 10 registros con valores aleatorios.
insert into agenda (nombre, direccion, telefono) values ('Fernado','Larrea 234','123456789');

-- 8- Seleccione y muestre todos los registros de la tabla:
select * from agenda;

-- Felicitaciones usted ha armado su agenda personal!!!!

/*
		SQL Structured Query Language
		ANSI SQL
        
        DDL	Data Definition Language	(Estructura de tablas o metadatos)
        - create table
        - alter table	
        - drop table
        - truncate
        
        DML Data Manipulation Languaje	(registros)
        - insert
        - delete
        - update
        - select 
        
        DCL Data Control Language		(programación)
        
*/
use Clase02;

-- Comando DML select

-- * comodin todos los campos
select * from clientes;

select nombre,apellido from clientes;
select apellido,nombre from clientes;
select apellido,nombre,apellido, curdate() fecha from clientes;

select concat(apellido,' ',nombre) nombre, cuit, direccion from clientes;

create table facturas (
	letra char(1),
    numero int,
    fecha date,
    monto double,
    primary key(letra, numero)	-- clave primaria compuesta
);

insert into facturas (letra,numero,fecha,monto) values ('a',1000,curdate(),5000);
insert into facturas (letra,numero,fecha,monto) values ('a',1001,curdate(),3000);
insert into facturas (letra,numero,fecha,monto) values ('a',1002,curdate(),7500);
insert into facturas (letra,numero,fecha,monto) values ('a',1003,curdate(),5000*1.3);

select * from facturas;

-- columnas calculadas 
select letra,numero,fecha,monto, monto*1.21 monto_con_iva from facturas;

-- NO ANSI
select *, monto*1.21 monto_con_iva from facturas;

-- filtrado con where
select * from clientes;
select * from clientes where id<=5;

-- Pendiente terminar con where

-- Pendiente Base de datos negocio
