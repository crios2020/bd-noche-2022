drop database if exists biblioteca;
create database biblioteca;
use biblioteca;
create table tipoLibro(
	codTipoLibro int auto_increment primary key,
    descripcion varchar(45) not null
);
create table libros(
	codLibro int auto_increment primary key,
    nombre varchar(45) not null,
    autos varchar(45) not null,
    editorial varchar(45) not null,
    fechaPublicacion date,
    codTipoLibro int not null
);
alter table libros
	add constraint FK_codigoTipoLibro
    foreign key(codTipoLibro)
    references tipoLibro(codTipoLibro);
    
create table tipoSocio(
	categoriaSocio varchar(45) primary key,
    descripcion varchar(45)
);
create table socios(
	codSocio int auto_increment primary key,
    nombre varchar(20) not null,
    apellido varchar(20) not null,
    telefono varchar(20) not null,
    celular varchar(20),
    dni varchar(8) not null,
    direccion varchar(45) not null,
    codigoPostal varchar(12)not null,
    email varchar(45),
    categoriaSocio varchar(45) not null
);
alter table socios
	add constraint FK_categoriaSocio
    foreign key(categoriaSocio)
    references tipoSocio(categoriaSocio);
create table reserva(
	codSocio int not null,
    codLibro int not null,
    fechaReserva date not null,
    primary key(codSocio,codLibro,fechaReserva)
);
alter table reserva
	add constraint FK_codigoLibro
    foreign key(codLibro)
    references libros(codLibro);
alter table reserva
	add constraint FK_codigoSocio
    foreign key(codSocio)
    references socios(codSocio);

describe tipoLibro;
insert into tipoLibro (descripcion) values ("Educativo");
describe libros;
insert into libros (nombre,autos,editorial,fechaPublicacion,codTipoLibro) values
	("La Biblia de Java","JavaJava","EMECE",curdate(),1);
describe tipoSocio;
insert into tipoSocio (categoriaSocio,descripcion) values ("VIP","Very Importan People");
describe socios;
insert into socios (nombre,apellido,telefono,celular,dni,direccion,codigoPostal,email,categoriaSocio) values
	('Juan','Peirano','233232','12345678','12345678','Lima 222','12333','Juan@gmail.com','VIP');
describe reserva;
insert into reserva (codSocio,codLibro,fechaReserva) values (1,1,curdate());

select * from tipoLibro tl join libros l on tl.codTipoLibro=l.codTipoLibro
	join reserva r on l.codLibro=r.codLibro
    join socios s on r.codSocio=s.codSocio
    join tipoSocio ts on s.categoriaSocio=ts.categoriaSocio;
    