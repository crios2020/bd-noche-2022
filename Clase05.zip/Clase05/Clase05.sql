use negocio;
show tables;
describe articulos;
describe clientes;
describe facturas;
select * from articulos;
select * from clientes;
select * from facturas;

-- Comando DML Select
-- Filtrado con where
select * from clientes where codigo=3;
select * from clientes where nombre='Laura';

-- Operadores relacionales < <= > >= = <> !=
select * from clientes where codigo<3;
select * from clientes where codigo<=3;
select * from clientes where nombre<'Laura';
select * from facturas where fecha<='2020/09/01';

select * from clientes where codigo>3;
select * from clientes where codigo>=3;
select * from clientes where nombre>='Laura';
select * from facturas where fecha>'2020/09/01';

select * from clientes where codigo!=3;
select * from clientes where codigo<>3;

select * from clientes where nombre!='Laura';
select * from clientes where nombre<>'Laura';

select * from facturas where fecha!=curdate();
select * from facturas where fecha<>curdate();

-- Operadores logicos	and or
insert into clientes (nombre,apellido) values 
	('Juan','Perez'),
    ('Juan','Gomez'),
    ('Laura','Gomez'),
    ('Laura','Perez'),
    ('Juan','Perez');
    
select * from clientes where nombre='Juan';
select * from clientes where nombre='Juan' or nombre='Laura';
select * from clientes where nombre='Juan' or apellido='Perez';
select * from clientes where nombre='Juan' and apellido='Perez';

-- columnas calculadas
select * from facturas;
select letra,numero,fecha,monto,monto*1.21 total_iva from facturas;
select letra,numero,fecha,monto,round(monto*1.21,2) total_iva from facturas;

insert into facturas values 
	('d',1111,curdate(),480),
    ('d',1112,curdate(),500),
    ('d',1113,curdate(),520),
    ('d',1114,curdate(),550),
    ('d',1115,curdate(),580),
    ('d',1116,curdate(),600),
    ('d',1117,curdate(),680);
-- clausula between not between
select * from facturas where monto >=500 and monto <=600;
select * from facturas where monto <500 or monto >600;

select * from facturas where monto between 500 and 600;
select * from facturas where monto not between 500 and 600;

-- clausula in - not in
select * from clientes 	
	where codigo=3
    or codigo=5
    or codigo=6
    or codigo=8;
select * from clientes where codigo in(3,5,6,8);
select * from clientes where codigo not in(3,5,6,8);

-- valores null
insert into clientes (nombre, apellido, direccion) values 
	('Ana','Moretti',''),
    ('Andres','Lorenzo',null);
insert into articulos (nombre,precio,stock) values
	('Cemento',0,100),
    ('Cal',null,20);

select * from clientes where direccion='';
select * from clientes where direccion is null;
select * from clientes where direccion is not null;

select * from clientes where direccion = null; -- Esto no funciona
insert into clientes (nombre,apellido,cuit,direccion,comentarios) values
					('Fernando','Torres','','','');
-- todos los registros que tengan algun campo null
select * from clientes where 
	codigo is null or 
    nombre is null or
    apellido is null or
    cuit is null or
    direccion is null or
    comentarios is null;

-- Ordenar registro
select * from clientes;
select * from clientes order by apellido;
select * from clientes order by apellido,nombre;
select * from clientes order by apellido asc,nombre asc;
select * from clientes order by apellido desc,nombre desc;
select * from clientes order by apellido desc,nombre;

-- Asuntos de performance
-- no tiene buena performance 
-- 		usar select * -- select nombre,apellido
-- 		no usar where
-- 		usar order by


insert into clientes (nombre,apellido) values
	('Omar','Lopez'),('Armando','Lopez'),
    ('Mario','Lopez'),('Mariano','Lopez'),
    ('Mariana','Lopez'),('Mirta','Lopez'),
    ('Marta','Lopez'),('Mariela','Lopez'),
    ('Monica','Lopez'),('Magali','Lopez'),
    ('Mercedes','Lopez'),('Miriam','Lopez'),
    ('Maria','Lopez'),('Mery','Lopez');
-- LIKE NOT LIKE
select * from clientes where nombre like 'm%';
select * from clientes where nombre not like 'm%';
select * from clientes where nombre like 'ma%';
select * from clientes where nombre like 'mar%';
select * from clientes where nombre like '%a';
select * from clientes where nombre like 'm%a';
select * from clientes where nombre like '%ar%';
select * from clientes where nombre like 'm_r%';
select * from clientes where nombre like '___';
select * from clientes where nombre like '____';
select * from clientes where nombre like '_____%';
select * from clientes where nombre not like '_____%';


-- Laboratorio 3
-- 1 - Ingrese a la base de datos negocio.

-- 2 - Ingrese 5 registros aleatorios en cada tabla.

-- 3 - Basándose en la tabla artículos obtener los siguientes listados.

-- a-	artículos con precio mayor a 100
select * from articulos where precio >100;
-- b-	artículos con precio entre 20 y 40 (usar < y >)
select * from articulos where precio >=20 and precio <=40;
-- c-	artículos con precio entre 40 y 60 (usar BETWEEN)
select * from articulos where precio between 40 and 60;
-- d-	artículos con precio = 20 y stock mayor a 30
select * from articulos where precio = 20 and stock >30;
-- e-	artículos con precio (12,20,30) no usar IN
select * from articulos where precio=12 or precio=20 or precio=30;
-- f-	artículos con precio (12,20,30) usar el IN
select * from articulos where precio in(12,20,30);
-- g-	artículos que su precio no sea (12,20,30)
select * from articulos where precio not in (12,20,30);
-- h-   artículos que su precio mas iva(21 %) sea mayor a 100
select * from articulos where precio*1.21>100;
-- i-   listar nombre de los artículos que no cuesten $100
select nombre from articulos where precio<>100;
select nombre from articulos where precio not in(100);
-- j- 	artículos con nombre que contengan la cadena 'lampara' (usar like)
select * from articulos where nombre like '%lampara%';
-- k-   artículos que su precio sea menor que 200 y en su nombre no contenga la letra 'a'
select * from articulos where precio <200 and nombre not like '%a%';

-- 	2- Listar los artículos ordenados por precio de mayor a menor, 
--     y si hubiera precio iguales deben quedar ordenados por nombre.
select * from articulos order by precio desc,nombre;
-- 	3- Listar todos los artículos incluyendo una columna denominada 
--     precio con IVA, la cual deberá tener el monto con el iva del producto.
select codigo,nombre,precio,precio*1.21 precio_con_IVA, stock from articulos;
-- 	4- Listar todos los artículos incluyendo una columna denominada 
--     'cantidad de cuotas' y otra 'valor de cuota', la cantidad es fija y es 3, 
--     el valor de cuota corresponde a 1/3 del monto con un 5% de interés.
select codigo,nombre,precio, 3 cantidad_de_cuotas, 
		round(precio/3*1.05) valor_cuota, stock 
		from articulos;






