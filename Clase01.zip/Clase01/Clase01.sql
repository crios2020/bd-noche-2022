/*
    Curso: Base de datos SQL        70hs
    Días: Miércoles 18:30 hs
    Profe: Carlos Rios          c.rios@bue.edu.ar

    Materiales:     
        Github: https://github.com/crios2020/bd-noche-2022
        Aula Virtual: https://aulasvirtuales.bue.edu.ar/
        videos tutoriales: https://www.youtube.com/playlist?list=PLMLmotKSEKYfAXzL8O62KUgc6TpJ-mC-6

    Materiales extra:
        https://www.tutorialesprogramacionya.com/
        https://open-bootcamp.com/

    recordatorio github programación:
        https://github.com/crios2020/tecnicas-noche-2022

    Software: 
                Server:     MySQL Community Server
                            MariaDB Community Server

                Client:     MySQL Workbench https://dev.mysql.com/downloads/workbench/

    Paquete XAMPP           https://www.apachefriends.org/

        X           Linux/Windows/Mac
        A           Apache Web Server
        M           MySQL / MariaDB Community Server
        P           PHP
        P           Perl

    Paquete WAMP    wampserver.com
    Paquete LAMP
    Paquete MAMP    
*/

-- comentario de una sola linea
/* Bloque de comentarios */

show databases;		-- muestra las bds del sever
-- ; es el terminador de sentencias
-- ctrol enter - atajo para ejecutar el comando

SHOW DATABASES;		-- lenguaje no case sensitive

select 'Hola Mundo!!';

create database clase01;		-- crea la base clase01
CREATE DATABASE CLASE01;

use clase01;					-- entra o activa la bd clase01

show tables;					-- muestra el catalogo de tablas
