-- borro una bd
drop database if exists Clase02;

-- crear una bd
create database Clase02;

-- mostrar las bd
show databases;

-- entrar a la bd
use Clase02;

-- mostrar tablas de la bd
show tables;

/*
		Memoria Ram:	Muy Veloz		Muy Cara		Volatil
        Disco Duro:		Muy Lento		Muy Barato		Persistente
        
        Planilla		Tabla
        columnas	= 	campos
        filas		= 	registros
*/

-- borrar la tabla
drop table if exists clientes;

-- creamos la tabla clientes
create table clientes(
	id 			int 		auto_increment primary key, 
	nombre 		varchar(25) not null, 
	apellido 	varchar(25) not null, 
	cuit 		char(13), 
	direccion 	varchar(50), 
	comentarios varchar(255)
	-- indentado
);

describe clientes;	-- metadato de la tabla

-- mostrar registros de tabla
select * from clientes;

-- Insertar registros
insert into clientes (nombre,apellido,cuit,direccion,comentarios) values
	('Nadia','Herrera','1233456','Medrano 123','');
insert into clientes (nombre,apellido,cuit,direccion,comentarios) values
	('Mariana','Garcia','233333','Lima 222','');
insert into clientes (nombre,apellido,cuit,direccion,comentarios) values
	('Jose','Mendoza','636363','Peru 650','');
insert into clientes (nombre,apellido,cuit,direccion,comentarios) values
	('Matias','Moreno','993939','Viel 234','');
insert into clientes (nombre,apellido,cuit,direccion,comentarios) values
	('Andrea','Moretti','555555','Maipu 345','');

-- No Ansi SQL
insert clientes (nombre,apellido,cuit,direccion,comentarios) values
	('Cristian','Molina','555555','Maipu 345','');
-- No Ansi SQL
INSERT INTO `Clase02`.`clientes` (`nombre`, `apellido`, `cuit`, `direccion`) VALUES 
	('Mario', 'Morello', '44444', 'Lima 222');
INSERT INTO `Clase02`.`clientes` (`nombre`, `apellido`, `cuit`, `direccion`) VALUES 
	('Liliana', 'Garcia', '22222', 'Medrano 222');

/*
	Tipo de datos SQL
    
    Tipo de datos texto
    
    nombre char(20)
    
    |ANA                 |				20 bytes
    |CARLOS              |				20 bytes
    |MAXIMILIANO         |				20 bytes
								Total:	60 bytes
    
    nombre varchar(20) x+1
    
    |ANA                 |		 3 + 1	 04 bytes		
    |CARLOS              |		 6 + 1   07 bytes
    |MAXIMILIANO         |		11 + 1	 11 bytes
								Total:	 23 bytes
    
    tipo de datos enteros
    
    Tipo			Ocupa		Rango										java
    boolean			1 byte		0-255	0 false, distinto de 0 true			boolean
    tinyint			1 byte		2^8  256									byte
    smallint		2 bytes		2^16 65536									short
    mediumint		3 bytes		2^24 16m
    int - integer	4 bytes		2^32 4000m									int
    bigint			8 bytes	 	2^64										long
    
    Tipo de datos punto flotante
    
    Tipo			Ocupa													Java
    float			4 bytes													float
    double			8 bytes													double
    
    decimal(t,d)	t+2		t cantidad total de digitos
							d decimales
                            
	precio(6,2)		8 bytes
		9999,99
		----,--
        
	precio(7,2)		9 bytes
		99999,99
		-----,--
        
	precio(7,3)		9 bytes
        9999,999
        ----,---
        
    codigo tinyint signed
    
    |----|----|
  -128   0   127
  
	codigo tinyint unsigned
    
    |---------|
    0		 255
  
    Tipo de datos fecha y hora
    
    Tipo		ocupa
    date		3 bytes			'2022-08-17'
    time		3 bytes			'22:59:00'
    datetime	8 bytes	
*/

select 'Hola Mundo!';
select 2+2;

-- Uso del alias
select 2+2 total;
select 2+2 as total;
select 2+2 valor_total;
select 2+2 'valor total';

select PI() pi;
select round(pi(),2) pi;

select curdate() fecha_actual;
select curtime() hora_actual;
select sysdate() fecha_hora;

-- Pendiente
-- Primer actividad práctica	(agenda)




