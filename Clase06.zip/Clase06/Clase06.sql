use negocio;
show tables;
describe articulos;
describe clientes;
describe facturas;
select * from articulos;
select * from clientes;
select * from facturas;

-- Comando DML insert

-- Insert normal con definición de campos			(ANSI SQL)
insert into clientes (nombre,apellido,direccion) values ('Ana','Sequeria','Lima 22');

-- Insert abreviado sin definición de campos		(ANSI SQL)
insert into clientes values (null,'Juan','Lezama','22223','Peru 544','');

select * from clientes;

-- insert set (NO ANSI)
insert clientes set nombre='Raul', apellido='Quintana';

-- insert masivo (ANSI)
insert into clientes (nombre, apellido) values
	('Matias','Fernandez'),
    ('Miriam','Lezcano'),
    ('Leandro','Casas'),
    ('Mariela','Revoredo');

-- Comando DML update ANSI
update clientes set nombre='Hernan' where codigo=4;
update clientes set nombre='Jimena', apellido='Garcia' where codigo=5;
update clientes set nombre='Juana' where nombre='Juan';
set sql_safe_updates=0;

-- Comando DDL delete ANSI
delete from clientes where codigo=10;
delete from clientes where nombre='Juan';
-- delete from clientes;


-- Usando la base de datos negocio.

-- Basándose en la tabla clientes realizar los siguientes puntos.

-- 1- 	Insertar 5 clientes en la tabla clientes utilizando el insert into sin utilizar campos como parte de la sentencias, es decir de la forma simplificada.
-- 2-	Insertar 5 clientes en la tabla clientes utilizando los campos como parte de la sentencias, es decir de la forma extendida. Completar solo los campos nombre, apellido y CUIT.
-- 3-	Actualizar el nombre del cliente 1 a Jose.
update clientes set nombre='Jose' where codigo=1;
-- 4-	Actualizar el nombre apellido y cuit del cliente 3 a Pablo Fuentes 20-21053119-0.
update clientes set nombre='Pablo', apellido='Fuentes', cuit='20-21053119-0' where codigo=3;
-- 5-	Actualizar todos los comentarios NULL  a ''.
update clientes set comentarios ='' where comentarios is null;
-- 6-	Eliminar los clientes con apellido Perez.
delete from clientes where apellido='Perez';
-- 7-	Eliminar los clientes con CUIT Terminan en 0.
delete from clientes where cuit like '%0';
-- Laboratorio
-- Basando se en la tabla artículos, realizar los siguientes puntos.
-- 	8- Aumentar un 20% los precios de los artículos con precio menor igual a 50.
update articulos set precio=precio*1.2 where precio<=50;
-- 	9- Aumentar un 15% los precios de los artículos con precio mayor a 50.
update articulos set precio=precio*1.15 where precio>50;
-- 	10- Bajar un 5% los precios de los artículos con precio mayor a 200.
update articulos set precio=precio*0.95 where precio>200; 
-- 	11- Eliminar los artículos con stock menor a 0.
delete from articulos where stock<0;

-- 	12- Agregar a la tabla articulos, los campos stockMinimo y stockMaximo. (usar alter table add)
alter table articulos add stockMinimo int;
alter table articulos add stockMaximo int;
describe articulos;
select * from articulos;

--  13- Completar en los registros los valores de los campos stockMinimo y stockMaximo (usar update)
--      teniendo en cuenta que el stock mínimo debe ser menor que el stock máximo.
update articulos set stockMinimo=10, stockMaximo=50; 
--  14- Lista los articulos que se deben reponer y que cantidad se debe reponer de cada articulos.
--      Tener en cuenta que se debe reponer cuando el stock es menor al stockMinimo y la cantidad de articulos a 
--      reponer es stockMaximo - stock.
select codigo,nombre,precio,stock,stockMinimo,stockMaximo, stockMaximo-stock cantidad_a_reponer
	from articulos where stock < stockMinimo;
--  15- Calcular el valor de venta de toda la mercaderia que hay en stock.
--  16- Calcular el valor de venta + iva de toda la mercaderia que hay en stock.

select * from articulos;
update articulos set stock=stock-5;
update articulos set precio=round(precio,2);

-- Comando Alter Table		DDL  ANSI
alter table clientes add edad int;
alter table clientes add DNI char(8) after cuit;
alter table clientes modify edad tinyint;
alter table clientes change direccion dir varchar(50);
alter table clientes change dir direccion varchar(50);

alter table clientes drop DNI;
alter table clientes drop edad;
select * from clientes;

-- Funciones de agrupamiento

-- Funcion max
select max(precio) from articulos;
select max(precio) precio_max from articulos;
select max(nombre) from clientes;
select max(fecha) ultima_fecha from facturas;

select min(precio) precio_min from articulos;
select min(nombre) from clientes;
select min(fecha) primer_fecha from facturas;

insert into facturas values ('c',4001,curdate(),6000);
update articulos set precio=10 where precio=0;

select sum(monto) total from facturas;
select avg(monto) promedio from facturas;
select round(avg(monto),2) promedio from facturas;

select count(*) cantidad from clientes;

select count(direccion) cantidad from clientes;

select count(*) cantidad from clientes where direccion is not null;

-- subconsultas
select max(monto) monto_maximo from facturas;

select count(*) cantidad from facturas where monto=6000;
insert into facturas values ('c',4003,curdate(),6000);

select * from facturas where monto=6000;

select * from facturas where monto=(select max(monto) monto_maximo from facturas);

select sum(monto) total from facturas order by monto limit 5;

-- Agrupamientos con group by

select letra, sum(monto) total from facturas where letra='a';
select letra, sum(monto) total from facturas where letra='b';
select letra, sum(monto) total from facturas where letra='c';

/*
	letra	total
		a	3890
        b 	1000
        c  12300
        
*/

select letra, sum(monto) total from facturas group by letra having sum(monto)>=1000;

-- pendiente
-- Laboratorio
-- 1- Crear la tabla 'autos' en una nueva base de datos (Vehiculos) con el siguiente detalle:

-- 	codigo	INTEGER y PK
-- 	marca	VARCHAR(25)
-- 	modelo	VARCHAR(25)
-- 	color	VARCHAR(25)
-- 	anio	INTEGER
-- 	precio	DOUBLE

--  nota: (anio - año) seguramente tu computadora tiene soporte para la letra ñ,
--        pero muchas instalaciones (ej: web host alquilados) pueden que no tenga soporte para esa letra.
-- 		  en programación se acostumbra a usar los caracteres menores a 128 en la tabla ASCII.

-- 2- Agregar el campo patente despues del campo modelo.

-- 3- Cargar la tabla con 15 autos (hacerlo con MySQL WorkBench o el INSERT INTO).
-- 4- Realizar las siguientes consultas:
-- 	a. obtener el precio máximo.
-- 	b. obtener el precio mínimo.
-- 	c. obtener el precio mínimo entre los años 2010 y 2018.
-- 	d. obtener el precio promedio.
-- 	e. obtener el precio promedio del año 2016.
-- 	f. obtener la cantidad de autos.
-- 	g. obtener la cantidad de autos que tienen un precio entre $235.000 y $240.000.
-- 	h. obtener la cantidad de autos que hay en cada año.
-- 	i. obtener la cantidad de autos y el precio promedio en cada año.
-- 	j. obtener la suma de precios y el promedio de precios según marca.
--  k. informar los autos con el menor precio.
--  l. informar los autos con el menor precio entre los años 2016 y 2018.
--  m. listar los autos ordenados ascendentemente por marca,modelo,año.
--  n. contar cuantos autos hay de cada marca.
--  o. borrar los autos del siglo pasado.














